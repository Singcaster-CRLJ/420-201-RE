///\file main.c
///\author Patrick Singcaster (singcaster@clogik.io)

///\brief Fonction principale.
///\param argc Nombre de paramètres reçus.
///\param argv Paramètres reçus.
///\return Code de fin de programme.
int main(int argc, char* argv[]) {
	return 0;
}
